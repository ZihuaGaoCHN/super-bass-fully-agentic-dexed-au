Super Bass Fully Agentic Dexed — Windows x64 R6

Open Super Bass Fully Agentic Dexed.exe for standalone use.
Copy the complete .vst3 folder to your VST3 directory and rescan in your DAW.
This package is unsigned.
